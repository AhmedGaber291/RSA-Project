﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSA
{
    class BigInt
    {
        public BigInt()
        {


        }

        private Byte[] StringToInt(string str, int MaxSize)
        {
            Byte[] arr = new Byte[MaxSize];
            for (int i = MaxSize - 1; i >= 0; i--)
            {
                arr[i] = (Byte)(str[i] - 48); //48 ascii 
            }
            return arr;
        }

        private String IntToString(Byte[] arr)
        {

            char[] R = new char[arr.Length];
            for (int i = 0; i < arr.Length; i++)
            {
                R[i] = Char.Parse(arr[i].ToString());
            }
            String Result = new String(R);
            if (Result.StartsWith("0")) //3shan Elcarry
            {
                Result = Result.Remove(0, 1);
            }
            return Result;

        }


        public String Add(string X, string Y)
        {

            int difSize = Math.Abs(X.Length - Y.Length);

            int maxSize = Math.Max(X.Length, Y.Length);

            string NewStr = "";
            for (int i = 0; i < difSize; i++)
            {
                NewStr += "0";
            }
            if (Y.Length < X.Length)
            {
                NewStr += Y;
                Y = NewStr;
            }
            if (X.Length < Y.Length)
            {
                NewStr += X;
                X = NewStr;
            }
            Byte[] n1 = StringToInt(X, maxSize);
            Byte[] n2 = StringToInt(Y, maxSize);
            int carry = 0;
            Byte[] sum = new Byte[maxSize + 1];
            for (int i = maxSize; i > 0; i--)
            {
                sum[i] = (Byte)((n1[i - 1] + n2[i - 1] + carry) % 10);
                if (n1[i - 1] + n2[i - 1] + carry >= 10)
                {
                    carry = 1;
                }

                else carry = 0;

            }

            if (carry == 1)
            {
                sum[0] = 1;
            }
            return IntToString(sum);


           
        }


        static bool Below(string str1, string str2)
        {

            int l1 = str1.Length, l2 = str2.Length;

            if (l1 < l2)
                return true;
            else if (l1 > l2)
            {
                return false;
            }
            else
            {

                for (int i = 0; i < l1; i++)
                {
                    if (str1[i] > str2[i])
                    {
                        return false;
                    }
                    else if (str1[i] < str2[i])
                    {
                        return true;
                    }
                }

                return false;
            }
        }


        public string Substract(string str1,string str2)
        {

            if (Below(str1, str2))
            {
                string temp = str1;
                str1 = str2;
                str2 = temp;
            }
            int l1 = str1.Length, l2 = str2.Length;
            int diff = l1 - l2;
            string newstr = "";

            for (int i = 0; i < diff; i++)
            {
                newstr += "0";
            }

            newstr += str2;
            str2 = newstr;

            int carry = 0;
            int maxSize = Math.Max(l1, l2);
            int[] sub = new int[maxSize];
            Byte[] s = new Byte[maxSize];

            Byte[] s1 = StringToInt(str1, maxSize);
            Byte[] s2 = StringToInt(str2, maxSize);
            for (int i = l1 - 1; i >= 0; i--)
            {

                sub[i] = (Int16)((s1[i]) -
                          (s2[i]) - carry);
                if (sub[i] < 0)
                {
                    sub[i] = (Int16)(sub[i] + 10);
                    carry = 1;
                }
                else
                    carry = 0;


                if (s1[i] == 0 && s2[i] == 0 && carry > 0)
                {
                    s[i] += 9;
                    continue;
                }


                s[i] = (Byte)sub[i];
            }
            return IntToString(s);
        }

         public string _startMul(String X, String Y)
        {

            int ben = X.Length;
            int den = Y.Length;
            int curr_len = ben;
            if (ben < den)
                curr_len = den;

            if (curr_len != 1 && curr_len % 2 != 0)
                curr_len++;

            byte[] arrX = new byte[curr_len];
            byte[] arrY = new byte[curr_len];

            for (int i = 0; i < curr_len; i++)
            {
                arrX[i] = 0;
                arrY[i] = 0;
            }

            StringToByte1(X, ref arrX);
            StringToByte1(Y, ref arrY);

            return mul(ref arrX, ref arrY, 0, curr_len);
        }

         public string mul(ref byte[] X, ref byte[] Y, int MainIndex, int N)
        {
            string result = "";

            if (N == 1)
            {
                Int16 _temp1 = (Int16)(X[MainIndex] * Y[MainIndex]);
                result = Convert.ToString(_temp1);
                return result;
            }
            int first = N / 2;
            int second = N - first;
            int NewHIndex = MainIndex;
            int NewLIndex = MainIndex + first;
            //
            string a = _ByteArr2Str(ref X, NewHIndex, first);
            string b = _ByteArr2Str(ref X, NewLIndex, second);
            string c = _ByteArr2Str(ref Y, NewHIndex, first);
            string d = _ByteArr2Str(ref Y, NewLIndex, second);

            string _A = _startMul(a, c); //a * c
            string _D = _startMul(b, d); //b * d
            //

            string aPb = Add(a, b);
            string cPd = Add(c, d);

            string _E = _startMul(aPb, cPd);

            _E = Substract(_E, _A);
            _E = Substract(_E, _D);
            //
            string T1 = AddZeros2Right(_A, N);
            string T2 = AddZeros2Right(_E, N / 2);

            result = Add(T1, T2);
            result = Add(result, _D);

            return result;
        }
        public string AddZeros2Right(string _NumStr, int NumOfRightZeros)
        {
            string _StrWithZeros = _NumStr;
            for (int i = 0; i < NumOfRightZeros; i++)
            {
                _StrWithZeros = _StrWithZeros + "0";
            }
            return _StrWithZeros;
        }

        public string _ByteArr2Str(ref byte[] InArr, int _Index, int Len)
        {
            string _result = "";
            for (int i = 0; i < Len; i++)
            {
                if (InArr[_Index + i] != '0' || _result != "")
                    _result = _result + InArr[_Index + i];
            }
            return _result;
        }
        public  void StringToByte1(string str, ref Byte[] Arr1)
        {
            //Byte[] arr = new Byte[MaxSize];
            int _ArrIndex = Arr1.Length;
            for (int i = str.Length - 1; i >= 0; i--, _ArrIndex--)
            {
                //// Check str[i] to be between '0' , '9'
                Arr1[_ArrIndex - 1] = (Byte)(str[i] - 48); //48 ascii 
            }
            //return arr;
        }
    
    
    
    
 
    }
}
