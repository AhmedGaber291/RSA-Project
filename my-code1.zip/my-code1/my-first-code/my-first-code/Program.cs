﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace RSA
{
    class Program
    {
        static void Main(string[] args)
        {
                string result;
                BigInt Z = new BigInt();
                string skip;
                StreamReader sr;
                StreamWriter sw = new StreamWriter("AddTestCases_Output.txt ");
                int NumOfCases;
                string num1;
                string num2;
                sr = new StreamReader("AddTestCases.txt");
                NumOfCases = int.Parse(sr.ReadLine());
                for (int i = 0; i < NumOfCases; i++)
                {
                    skip = sr.ReadLine();
                    num1 = sr.ReadLine();
                    num2 = sr.ReadLine();
                    result = Z.Add(num1, num2);
                    sw.Write(result);
                    if (i != NumOfCases - 1)
                    {
                        sw.WriteLine();
                        sw.WriteLine();
                    }
                }

                sr.Close();
                sw.Close();
            string resultofsub;
            BigInt R = new BigInt();
            string skip2;
            StreamReader sr2;
            StreamWriter sw2 = new StreamWriter("SubtractTestCases_Output.txt ");
            int NumOfCasesofsub;
            string str1;
            string str2;

            sr2 = new StreamReader("SubtractTestCases.txt");
            NumOfCasesofsub = int.Parse(sr2.ReadLine());
            for (int i = 0; i < NumOfCasesofsub; i++)
            {
                skip2 = sr2.ReadLine();
                str1 = sr2.ReadLine();
                str2 = sr2.ReadLine();
                resultofsub = Z.Substract(str1, str2);
                sw2.Write(resultofsub);
                if (i != NumOfCasesofsub - 1)
                {
                    sw2.WriteLine();
                    sw2.WriteLine();
                }
            }
            sr2.Close();
            sw2.Close();





            string mulres;
            BigInt M = new BigInt();
            string skip3;
            StreamReader sr4;
            StreamWriter sw4 = new StreamWriter("MultiplyRES.txt ");
            int NumOfCasesmul;
            string _str1;
            string _str2;
            sr4 = new StreamReader("MultiplyTestCases.txt");
            NumOfCasesmul = int.Parse(sr4.ReadLine());
            for (int i = 0; i < NumOfCasesmul; i++)
            {
                skip3 = sr4.ReadLine();
                _str1 = sr4.ReadLine();
                _str2 = sr4.ReadLine();
                mulres = Z._startMul(_str1, _str2);
                sw4.Write(mulres);
                if (i != NumOfCasesmul - 1)
                {
                    sw4.WriteLine();
                    sw4.WriteLine();
                }
            }
            sr4.Close();
            sw4.Close();
        
        
        
        
        
        
        
        


        }
    }
}
